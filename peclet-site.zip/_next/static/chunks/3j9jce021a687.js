(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,76713,e=>{e.v({aperture:"DaylightInstrument-module__vnONWG__aperture",curve:"DaylightInstrument-module__vnONWG__curve",curveArea:"DaylightInstrument-module__vnONWG__curveArea",overlaySvg:"DaylightInstrument-module__vnONWG__overlaySvg",readout:"DaylightInstrument-module__vnONWG__readout",room:"DaylightInstrument-module__vnONWG__room",term:"DaylightInstrument-module__vnONWG__term",threshold:"DaylightInstrument-module__vnONWG__threshold",tick:"DaylightInstrument-module__vnONWG__tick",value:"DaylightInstrument-module__vnONWG__value"})},71834,e=>{e.v({demandBar:"EnergyBalance-module__26VM4a__demandBar",demandLabel:"EnergyBalance-module__26VM4a__demandLabel",demandUnit:"EnergyBalance-module__26VM4a__demandUnit",demandValue:"EnergyBalance-module__26VM4a__demandValue",flow:"EnergyBalance-module__26VM4a__flow",rail:"EnergyBalance-module__26VM4a__rail",ribbon:"EnergyBalance-module__26VM4a__ribbon",ribbonFlow:"EnergyBalance-module__26VM4a__ribbonFlow",svg:"EnergyBalance-module__26VM4a__svg",termLabel:"EnergyBalance-module__26VM4a__termLabel",termValue:"EnergyBalance-module__26VM4a__termValue",wrap:"EnergyBalance-module__26VM4a__wrap"})},56572,e=>{e.v({drift:"MoistureInstrument-module__716S6q__drift",plane:"MoistureInstrument-module__716S6q__plane",planeLabel:"MoistureInstrument-module__716S6q__planeLabel",side:"MoistureInstrument-module__716S6q__side",sideLeft:"MoistureInstrument-module__716S6q__sideLeft",sideName:"MoistureInstrument-module__716S6q__sideName",sideRight:"MoistureInstrument-module__716S6q__sideRight",sideValue:"MoistureInstrument-module__716S6q__sideValue",verdict:"MoistureInstrument-module__716S6q__verdict",verdictRisk:"MoistureInstrument-module__716S6q__verdictRisk",verdictSafe:"MoistureInstrument-module__716S6q__verdictSafe"})},71784,e=>{e.v({compass:"SolarInstrument-module__00nDfq__compass",readout:"SolarInstrument-module__00nDfq__readout",row:"SolarInstrument-module__00nDfq__row",state:"SolarInstrument-module__00nDfq__state",stateUp:"SolarInstrument-module__00nDfq__stateUp",term:"SolarInstrument-module__00nDfq__term",value:"SolarInstrument-module__00nDfq__value"})},33950,e=>{"use strict";var t=e.i(43476),a=e.i(71645),n=e.i(94800),r=e.i(90072);let l=[{cx:.46,cy:.39,hx:.11,hy:.23},{cx:.64,cy:.25,hx:.07,hy:.09}],i=[{cx:.46,cy:.5,hx:.14,hy:.028},{cx:.46,cy:.28,hx:.14,hy:.022}];function s(e){return`sdBox(p, vec2(${e.cx}, ${e.cy}), vec2(${e.hx}, ${e.hy}))`}let o=`
float sdBox(vec2 p, vec2 c, vec2 h) {
  vec2 d = abs(p - c) - h;
  return length(max(d, 0.0)) + min(max(d.x, d.y), 0.0);
}

float sdBoxScaled(vec2 p, vec2 c, vec2 h, float k) {
  vec2 d = abs(p - c) - vec2(h.x, h.y * k);
  return length(max(d, 0.0)) + min(max(d.x, d.y), 0.0);
}

float sdMassing(vec2 p, float porosity) {
  float solid = min(
    ${s(l[0])},
    ${s(l[1])}
  );

  // Ground: everything below the line is solid too.
  solid = min(solid, p.y - 0.16);

  float k = max(porosity, 0.001);
  float openings = min(
    sdBoxScaled(p, vec2(${i[0].cx}, ${i[0].cy}),
                vec2(${i[0].hx}, ${i[0].hy}), k),
    sdBoxScaled(p, vec2(${i[1].cx}, ${i[1].cy}),
                vec2(${i[1].hx}, ${i[1].hy}), k)
  );

  return max(solid, -openings);
}
`;var u=e.i(51315);let d=`
uniform float uTime;
uniform vec2  uWind;
uniform float uPorosity;

attribute float aEnd;

varying float vSpeed;
varying float vAlpha;

const int STEPS = 13;
const float LIFETIME = 3.2;
const float SPEED = 0.32;
const float TRAIL = 0.2;

${o}

// Forward-difference gradient, reusing the distance already in hand: three
// field evaluations per normal instead of four.
vec2 sdNormal(vec2 p, float d0) {
  vec2 e = vec2(0.004, 0.0);
  vec2 n = vec2(
    sdMassing(p + e.xy, uPorosity) - d0,
    sdMassing(p + e.yx, uPorosity) - d0
  );
  float len = length(n);
  return len > 1e-5 ? n / len : vec2(0.0, 1.0);
}

vec2 flow(vec2 p) {
  float d = sdMassing(p, uPorosity);

  // Far field is simply the wind. Skipping the gradient here is what makes
  // integrating a whole field of streamlines affordable.
  if (d > 0.17) return uWind;

  vec2 n = sdNormal(p, d);

  // Inside a solid there is no flow worth drawing; drift outward so a carrier
  // seeded in the wall leaves rather than sitting there.
  if (d < 0.0) return n * 0.3;

  vec2 v = uWind;

  // Close to a surface, cancel the component driving into it and let what is
  // left speed up along the face.
  float influence = exp(-d * 22.0);
  float into = min(dot(v, n), 0.0);
  v -= n * into * (1.0 + influence * 0.9);

  vec2 tangent = vec2(-n.y, n.x);
  float side = dot(tangent, uWind) >= 0.0 ? 1.0 : -1.0;
  v += tangent * side * influence * 0.6;

  // Leeward stall. A face whose normal points downwind is in the lee, so the
  // sign here is positive: n pointing with the wind means sheltered.
  float lee = clamp(dot(n, uWind), 0.0, 1.0);
  v *= 1.0 - lee * influence * 0.88;

  return v;
}

vec2 integrate(vec2 seed, float tau) {
  float h = tau / float(STEPS);
  vec2 p = seed;
  for (int i = 0; i < STEPS; i++) {
    // Midpoint step — cheap, and it holds the line around a corner where
    // plain Euler would cut straight through the fa\xe7ade.
    vec2 k1 = flow(p);
    vec2 k2 = flow(p + k1 * h * SPEED * 0.5);
    p += k2 * h * SPEED;
  }
  return p;
}

void main() {
  vec2 seed = position.xy;
  float phase = position.z;

  float life = fract(uTime / LIFETIME + phase);
  float tau = (life - 0.5) * LIFETIME;

  vec2 p = integrate(seed, tau + aEnd * TRAIL);

  vec2 v = flow(p);
  vSpeed = clamp(length(v), 0.0, 1.7);

  // Brightest at the seed, fading toward both ends of the sweep.
  vAlpha = clamp(cos(tau / LIFETIME * 3.14159265), 0.0, 1.0);

  // Hide anything that ended up inside the massing or outside the frame.
  if (sdMassing(p, uPorosity) < 0.0) vAlpha = 0.0;
  if (p.x < -0.03 || p.x > 1.03 || p.y < -0.03 || p.y > 1.03) vAlpha = 0.0;

  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}
`,c=`
precision mediump float;

uniform float uOpacity;

varying float vSpeed;
varying float vAlpha;

void main() {
  if (vAlpha <= 0.004) discard;

  // Slow air reads blue and quiet; fast air bleaches toward paper.
  vec3 slow = vec3(0.20, 0.36, 0.55);
  vec3 fast = vec3(0.94, 0.93, 0.90);
  vec3 colour = mix(slow, fast, clamp((vSpeed - 0.5) * 1.6, 0.0, 1.0));

  gl_FragColor = vec4(colour * vAlpha * uOpacity, 1.0);
}
`;function h({controls:e,count:l=2200}){let{animate:i}=(0,u.useVizEnv)(),s=(0,u.useAreaBudget)(l),o=(0,a.useMemo)(()=>{let e=new Float32Array(2*s*3),t=new Float32Array(2*s);for(let a=0;a<s;a++){let n=Math.random(),r=Math.random(),l=Math.random();for(let i=0;i<2;i++){let s=(2*a+i)*3;e[s]=n,e[s+1]=r,e[s+2]=l,t[2*a+i]=i}}let a=new r.BufferGeometry;return a.setAttribute("position",new r.BufferAttribute(e,3)),a.setAttribute("aEnd",new r.BufferAttribute(t,1)),a},[s]),m=(0,a.useMemo)(()=>({uTime:{value:0},uWind:{value:new r.Vector2(1,0)},uPorosity:{value:.6},uOpacity:{value:.6}}),[]),f=(0,a.useRef)(null),p=(0,a.useRef)(0),v=(0,a.useRef)(0),x=(0,a.useRef)(.6);return(0,n.useFrame)((t,a)=>{let n=Math.min(a,1/24);i&&(p.current+=n);let r=e.current,l=i?Math.min(1,4*n):1,s=r.angle-v.current;for(;s>Math.PI;)s-=2*Math.PI;for(;s<-Math.PI;)s+=2*Math.PI;v.current+=s*l,x.current+=(r.porosity-x.current)*l;let o=f.current;o&&(o.uniforms.uTime.value=p.current,o.uniforms.uWind.value.set(Math.cos(v.current),Math.sin(v.current)),o.uniforms.uPorosity.value=x.current)}),(0,t.jsx)("lineSegments",{frustumCulled:!1,geometry:o,children:(0,t.jsx)("shaderMaterial",{ref:f,vertexShader:d,fragmentShader:c,uniforms:m,transparent:!0,depthWrite:!1,depthTest:!1,blending:r.AdditiveBlending})})}var m=e.i(64135);function f({figure:e,hint:a,caption:n,controls:r,overlay:l,draggable:i=!1,stageRef:s,children:o}){return(0,t.jsxs)("figure",{className:m.default.instrument,"data-reveal":!0,children:[(0,t.jsxs)("div",{className:m.default.head,children:[(0,t.jsx)("span",{className:"label",children:e}),a?(0,t.jsx)("span",{className:`label ${m.default.hint}`,children:a}):null]}),(0,t.jsxs)("div",{ref:s,className:m.default.stage,"data-drag":i||void 0,children:[o,l?(0,t.jsx)("div",{className:m.default.overlay,children:l}):null]}),r?(0,t.jsx)("div",{className:m.default.controls,children:r}):null,(0,t.jsx)("figcaption",{className:m.default.caption,children:n})]})}function p({id:e,label:a,display:n,min:r,max:l,step:i,value:s,onChange:o,valueText:u}){return(0,t.jsxs)("div",{className:m.default.control,children:[(0,t.jsxs)("div",{className:m.default.controlHead,children:[(0,t.jsx)("label",{className:"label",htmlFor:e,children:a}),(0,t.jsx)("span",{className:m.default.controlValue,"aria-hidden":"true",children:n})]}),(0,t.jsx)("input",{id:e,className:m.default.slider,type:"range",min:r,max:l,step:i,value:s,onChange:e=>o(Number(e.target.value)),"aria-valuetext":u??n})]})}function v({label:e,options:a,active:n,onToggle:r}){return(0,t.jsxs)("div",{className:m.default.control,children:[(0,t.jsx)("div",{className:m.default.controlHead,children:(0,t.jsx)("span",{className:"label",id:`${e}-label`,children:e})}),(0,t.jsx)("div",{className:m.default.toggles,role:"group","aria-labelledby":`${e}-label`,children:a.map(e=>(0,t.jsx)("button",{type:"button",className:m.default.toggle,"aria-pressed":n.includes(e.id),onClick:()=>r(e.id),children:e.label},e.id))})]})}var x=e.i(941);let g=["E","NE","N","NW","W","SW","S","SE"];function _(e){return g[(Math.round((e%360+360)/45)+4)%8]}function y({discipline:e}){let n=(0,a.useRef)(null),[r,s]=(0,a.useState)(0),[o,d]=(0,a.useState)(.6),c=(0,a.useRef)({angle:0,porosity:.6}),m=e=>{s(e),c.current.angle=e*Math.PI/180};return(0,a.useEffect)(()=>{let e=n.current;if(!e)return;let t=!1,a=t=>{let a=e.getBoundingClientRect(),n=a.left+a.width/2,r=a.top+a.height/2;m(Math.round(180*Math.atan2(-(t.clientY-r),t.clientX-n)/Math.PI))},r=n=>{t=!0,e.setPointerCapture(n.pointerId),a(n)},l=e=>t&&a(e),i=a=>{t=!1,e.hasPointerCapture(a.pointerId)&&e.releasePointerCapture(a.pointerId)};return e.addEventListener("pointerdown",r),e.addEventListener("pointermove",l),e.addEventListener("pointerup",i),e.addEventListener("pointercancel",i),()=>{e.removeEventListener("pointerdown",r),e.removeEventListener("pointermove",l),e.removeEventListener("pointerup",i),e.removeEventListener("pointercancel",i)}},[]),(0,t.jsxs)(f,{figure:"Fig. 03 — Flow around and through",hint:"Drag anywhere on the field to turn the wind",caption:e.altText,draggable:!0,stageRef:n,controls:(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(p,{id:"air-angle",label:"Wind direction",display:`${r}\xb0 \xb7 from ${_(r)}`,valueText:`Wind from the ${_(r)}, ${r} degrees`,min:-180,max:180,step:1,value:r,onChange:m}),(0,t.jsx)(p,{id:"air-porosity",label:"Openings",display:o<.2?"Sealed":o<.6?"Partly open":"Open",valueText:`Openings ${Math.round(100*o)} per cent`,min:0,max:1,step:.01,value:o,onChange:e=>{d(e),c.current.porosity=e}})]}),overlay:(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)("svg",{className:x.default.overlaySvg,viewBox:"0 0 1000 1000",preserveAspectRatio:"none",role:"presentation","aria-hidden":"true",focusable:"false",children:[(0,t.jsx)("line",{className:x.default.ground,x1:0,y1:840,x2:1e3,y2:840}),l.map((e,a)=>(0,t.jsx)("rect",{className:x.default.solid,x:(e.cx-e.hx)*1e3,y:(1-(e.cy+e.hy))*1e3,width:2*e.hx*1e3,height:0+2*e.hy*1e3},`solid-${a}`)),i.map((e,a)=>(0,t.jsx)("rect",{className:x.default.opening,x:(e.cx-e.hx)*1e3,y:(1-(e.cy+e.hy*o))*1e3,width:2*e.hx*1e3,height:Math.max(2*e.hy*o*1e3,2)},`open-${a}`))]}),(0,t.jsxs)("div",{className:x.default.readout,children:[(0,t.jsx)("span",{className:x.default.term,children:"Wind from"}),(0,t.jsx)("span",{className:x.default.value,children:_(r)})]}),(0,t.jsxs)("svg",{className:x.default.windDial,viewBox:"0 0 100 100",role:"presentation","aria-hidden":"true",focusable:"false",children:[(0,t.jsx)("circle",{className:x.default.dialRing,cx:"50",cy:"50",r:"30"}),(0,t.jsxs)("g",{className:x.default.dialArrow,style:{transform:`rotate(${-r}deg)`},children:[(0,t.jsx)("line",{x1:"20",y1:"50",x2:"76",y2:"50"}),(0,t.jsx)("polyline",{points:"66,43 76,50 66,57",fill:"none"})]}),(0,t.jsx)("text",{className:x.default.dialLabel,x:"50",y:"14",children:"N"})]}),(0,t.jsxs)("div",{className:x.default.zones,children:[(0,t.jsx)("span",{className:x.default.zoneNote,children:"Windward — flow separates"}),(0,t.jsx)("span",{className:x.default.zoneNote,children:"Leeward — flow stalls"})]})]}),children:[(0,t.jsxs)(u.VizCanvas,{label:e.altText,interactive:!0,children:[(0,t.jsx)(u.Invalidate,{signal:`${r}|${o}`}),(0,t.jsx)(h,{controls:c})]}),(0,t.jsxs)("span",{className:"sr-only",children:["Wind arriving from the ",_(r),". The openings are"," ",o<.2?"sealed":o<.6?"partly open":"open",", so air ",o<.2?"passes only around":"passes both around and through"," ","the massing."]})]})}var b=e.i(48546);function w(e,t=48){let a=[];for(let n=0;n<=t;n++){let r=.08+.8400000000000001*n/t,l=Math.min(2.6*function(e,t){let a=.08-e,n=t.head-.72,r=.08-e,l=t.sill-.72,i=Math.hypot(a,n),s=Math.hypot(r,l);return i<1e-6||s<1e-6?1:Math.acos(Math.min(Math.max((a*r+n*l)/(i*s),-1),1))/Math.PI}(r,e),1);a.push({x:r,value:Math.pow(l,1.6)})}let n=a.reduce((e,t)=>Math.max(e,t.value),0);return n<1e-6?a.map(e=>({...e,value:0})):a.map(e=>({x:e.x,value:e.value/n}))}let M=`
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = vec4(position.xy * 2.0, 0.0, 1.0);
}
`,j=`
precision highp float;

uniform float uHead;
uniform float uSill;
uniform float uAltitude;   // radians
uniform float uAspect;
uniform float uTime;

varying vec2 vUv;

const float LEFT   = 0.08;
const float RIGHT  = 0.92;
const float TOP    = 0.14;
const float BOTTOM = 0.72;

float cross2(vec2 a, vec2 b) {
  return a.x * b.y - a.y * b.x;
}

void main() {
  // Screen space with y measured downward, matching the plan of the section.
  vec2 p = vec2(vUv.x, 1.0 - vUv.y);

  float inside = step(LEFT, p.x) * step(p.x, RIGHT)
               * step(TOP, p.y) * step(p.y, BOTTOM);

  // --- Diffuse: the angle the aperture subtends at this point -------------
  // A fixed gain rather than a normalising reference point. Dividing by the
  // value at the window wall saturates the whole room, because a point hard
  // against that wall sees the opening almost edge-on.
  vec2 v1 = normalize(vec2(LEFT - p.x, uHead - p.y) + 1e-6);
  vec2 v2 = normalize(vec2(LEFT - p.x, uSill - p.y) + 1e-6);
  float subtended = acos(clamp(dot(v1, v2), -1.0, 1.0)) / 3.14159265;

  // The subtended angle already falls roughly with distance; the exponent
  // carries it closer to the inverse-square falloff daylight actually shows.
  float diffuse = pow(clamp(subtended * 2.6, 0.0, 1.0), 1.6);

  // --- Direct: the wedge between rays from the two aperture edges ---------
  vec2 dir = normalize(vec2(cos(uAltitude), sin(uAltitude)));
  vec2 a = vec2(LEFT, uHead);
  vec2 b = vec2(LEFT, uSill);
  float sideA = cross2(dir, p - a);
  float sideB = cross2(dir, p - b);
  float ahead = step(0.0, dot(p - a, dir));
  float beam = step(sideA * sideB, 0.0) * ahead;

  // Soften the beam edges a little so it reads as light, not as a polygon.
  float edge = 1.0 - smoothstep(0.0, 0.02, min(abs(sideA), abs(sideB)));
  beam = max(beam, edge * ahead * 0.55);

  float sunUp = step(0.02, uAltitude);
  float direct = beam * sunUp * (0.35 + 0.65 * sin(clamp(uAltitude, 0.0, 1.5707963)));

  float light = clamp(diffuse * 0.95 + direct * 0.7, 0.0, 1.5);

  // Warm daylight, cooling slightly in the depth of the room.
  vec3 warm = vec3(0.96, 0.94, 0.90);
  vec3 cool = vec3(0.46, 0.55, 0.66);
  vec3 colour = mix(cool, warm, clamp(light * 0.7, 0.0, 1.0));

  float intensity = inside * clamp(light, 0.0, 1.5) * 0.42;

  // A whisper of grain, so large flat washes do not band.
  float grain = fract(sin(dot(vUv * 800.0, vec2(12.9898, 78.233))) * 43758.5453);
  intensity *= 0.97 + grain * 0.06;

  gl_FragColor = vec4(colour * intensity, intensity);
}
`;function S({controls:e}){let{animate:r}=(0,u.useVizEnv)(),{size:l}=(0,b.useThree)(),i=(0,a.useMemo)(()=>({uHead:{value:.26},uSill:{value:.5},uAltitude:{value:.7},uAspect:{value:1.78},uTime:{value:0}}),[]),s=(0,a.useRef)(null),o=(0,a.useRef)(0),d=(0,a.useRef)(.26),c=(0,a.useRef)(.5),h=(0,a.useRef)(.7);return(0,n.useFrame)((t,a)=>{let n=Math.min(a,1/24);r&&(o.current+=n);let i=e.current,u=.58,m=.198,f=Math.min(.198+.58*(.18+.62*i.aperture),.72-.04*u),p=i.altitude*Math.PI/180,v=r?Math.min(1,5*n):1;d.current+=(m-d.current)*v,c.current+=(f-c.current)*v,h.current+=(p-h.current)*v;let x=s.current;x&&(x.uniforms.uHead.value=d.current,x.uniforms.uSill.value=c.current,x.uniforms.uAltitude.value=h.current,x.uniforms.uAspect.value=l.width/Math.max(l.height,1),x.uniforms.uTime.value=o.current)}),(0,t.jsxs)("mesh",{frustumCulled:!1,children:[(0,t.jsx)("planeGeometry",{args:[1,1]}),(0,t.jsx)("shaderMaterial",{ref:s,vertexShader:M,fragmentShader:j,uniforms:i,transparent:!0,depthWrite:!1,depthTest:!1})]})}var N=e.i(76713);function I({discipline:e}){let[n,r]=(0,a.useState)(.45),[l,i]=(0,a.useState)(38),s=(0,a.useRef)({aperture:.45,altitude:38}),o=(0,a.useMemo)(()=>{let e,t;return{head:t=.14+.1*(e=.58),sill:Math.min(t+e*(.18+.62*n),.72-.04*e)}},[n]),d=(0,a.useMemo)(()=>w(o),[o]),c=(0,a.useMemo)(()=>{let e,t;return(t=(e=w(o,96)).reduce((e,t)=>Math.max(e,t.value),0))<1e-6?0:e[e.length-1].value/t},[o]),h=(0,a.useMemo)(()=>{let e,t;return e=w(o,96),t=0,e.forEach((a,n)=>{a.value>e[t].value&&(t=n)}),(e[t].x-.08)/.8400000000000001},[o]),m=.75,v=d.map((e,t)=>{let a=1e3*e.x,n=(m+.18*(1-Math.min(e.value,1)))*1e3;return`${0===t?"M":"L"} ${a.toFixed(1)} ${n.toFixed(1)}`}).join(" "),x=`${v} L ${920} ${(m+.18)*1e3} L ${80} ${(m+.18)*1e3} Z`,g=(m+.144)*1e3;return(0,t.jsxs)(f,{figure:"Fig. 05 — Daylight in section",hint:"Aperture size changes how far light reaches",caption:e.altText,controls:(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(p,{id:"daylight-aperture",label:"Aperture size",display:`${Math.round(20+62*n)} % of wall`,valueText:`Aperture ${Math.round(20+62*n)} per cent of the wall height`,min:0,max:1,step:.01,value:n,onChange:e=>{r(e),s.current.aperture=e}}),(0,t.jsx)(p,{id:"daylight-altitude",label:"Sun altitude",display:`${l.toFixed(0)}\xb0`,valueText:`Sun altitude ${l.toFixed(0)} degrees`,min:0,max:85,step:1,value:l,onChange:e=>{i(e),s.current.altitude=e}})]}),overlay:(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)("svg",{className:N.default.overlaySvg,viewBox:"0 0 1000 1000",preserveAspectRatio:"none",role:"presentation","aria-hidden":"true",focusable:"false",children:[(0,t.jsx)("rect",{className:N.default.room,x:80,y:140,width:840.0000000000001,height:580}),(0,t.jsx)("line",{className:N.default.aperture,x1:80,y1:1e3*o.head,x2:80,y2:1e3*o.sill}),(0,t.jsx)("path",{className:N.default.curveArea,d:x}),(0,t.jsx)("path",{className:N.default.curve,d:v}),(0,t.jsx)("line",{className:N.default.threshold,x1:80,y1:g,x2:920,y2:g})]}),(0,t.jsxs)("div",{className:N.default.readout,children:[(0,t.jsx)("span",{className:N.default.term,children:"Back of room"}),(0,t.jsxs)("span",{className:N.default.value,children:[Math.round(100*c)," % of peak"]}),(0,t.jsxs)("span",{className:N.default.term,children:["Brightest at ",Math.round(100*h)," % depth"]})]})]}),children:[(0,t.jsxs)(u.VizCanvas,{label:e.altText,children:[(0,t.jsx)(u.Invalidate,{signal:`${n}|${l}`}),(0,t.jsx)(S,{controls:s})]}),(0,t.jsxs)("span",{className:"sr-only",children:["With the aperture at ",Math.round(20+62*n)," per cent of the wall height and the sun ",l.toFixed(0)," degrees above the horizon, daylight on the floor is strongest about ",Math.round(100*h)," per cent of the way into the room, and the back of the room receives about"," ",Math.round(100*c)," per cent of that peak. The plotted curve shows the distribution along the floor. Values are relative and indicative, not measured illuminance."]})]})}var T=e.i(71834);let A=[{id:"solar",label:"Solar gain",baseline:32,colour:"#c2703f",reducedBy:{shading:.66,glazing:.24}},{id:"fabric",label:"Fabric conduction",baseline:21,colour:"#8c7fb8",reducedBy:{fabric:.48}},{id:"infiltration",label:"Infiltration",baseline:18,colour:"#3f8fa8",reducedBy:{airtightness:.62,fabric:.08}},{id:"internal",label:"Internal gain",baseline:17,colour:"#6f9464",reducedBy:{equipment:.38}},{id:"latent",label:"Latent load",baseline:12,colour:"#4c7db8",reducedBy:{airtightness:.34}}],$=[{id:"shading",label:"External shading"},{id:"fabric",label:"Fabric + cool roof"},{id:"airtightness",label:"Airtightness"},{id:"glazing",label:"Glazing spec"},{id:"equipment",label:"Efficient equipment"}];function E(e){let t=A.map(t=>{let a=1;for(let[n,r]of Object.entries(t.reducedBy))e.includes(n)&&(a*=1-r);return{...t,value:t.baseline*a}}),a=t.reduce((e,t)=>e+t.value,0);return{terms:t,total:a}}function F({active:e}){let{terms:a,total:n}=E(e),r=Math.max(2.6*n,6),l=200-r/2;return(0,t.jsx)("div",{className:T.default.wrap,children:(0,t.jsxs)("svg",{className:T.default.svg,viewBox:"0 0 820 400",role:"presentation","aria-hidden":"true",focusable:"false",children:[a.map((e,n)=>{let l=78+62*n,i=200-r/2+r*((n+.5)/a.length),s=`M 210 ${l} C 380 ${l}, 430 ${i}, 600 ${i}`,o=Math.max(1.55*e.value,.6),u=e.value<.98*e.baseline;return(0,t.jsxs)("g",{children:[(0,t.jsx)("text",{className:T.default.termLabel,x:"16",y:l-10,children:e.label}),(0,t.jsxs)("text",{className:T.default.termValue,x:"16",y:l+14,children:[e.value.toFixed(0),u?` / ${e.baseline}`:""]}),(0,t.jsx)("line",{className:T.default.rail,x1:"16",y1:l-4,x2:210,y2:l-4,opacity:"0.25"}),(0,t.jsx)("path",{className:T.default.ribbon,d:s,stroke:e.colour,strokeWidth:o,opacity:.3}),(0,t.jsx)("path",{className:T.default.ribbonFlow,d:s,stroke:e.colour,strokeWidth:o})]},e.id)}),(0,t.jsx)("rect",{className:T.default.demandBar,x:660,y:l,width:"10",height:r,fill:"var(--paper)"}),(0,t.jsx)("text",{className:T.default.demandLabel,x:686,y:l+14,children:"Residual demand"}),(0,t.jsx)("text",{className:T.default.demandValue,x:686,y:l+52,children:n.toFixed(0)}),(0,t.jsx)("text",{className:T.default.demandUnit,x:686,y:l+70,children:"Index · baseline = 100"})]})})}function P({discipline:e}){let[n,r]=(0,a.useState)([]),{terms:l,total:i}=E(n),s=[...l].sort((e,t)=>t.value-e.value)[0],o=`${e.altText} The figures are an illustrative index in which the untreated baseline is defined as 100. They compare the relative effect of measures on one another and are not a calculation, prediction or claim about any building.`;return(0,t.jsxs)(f,{figure:"Fig. 06 — Cooling-season balance",hint:"Switch measures on and off",caption:o,controls:(0,t.jsx)(v,{label:"Measures applied",options:$,active:n,onToggle:e=>r(t=>t.includes(e)?t.filter(t=>t!==e):[...t,e])}),children:[(0,t.jsx)(F,{active:n}),(0,t.jsxs)("span",{className:"sr-only",children:["With ",0===n.length?"no measures":`${n.length} measures`," ","applied, the residual demand index stands at ",i.toFixed(0)," against a baseline of 100. The largest remaining term is ",s.label," at"," ",s.value.toFixed(0),". Terms:"," ",l.map(e=>`${e.label} ${e.value.toFixed(0)}`).join(", "),"."]})]})}var L=e.i(39023);let R=`
uniform float uTime;
uniform float uHumidity;
uniform float uDew;
uniform float uPixelRatio;
uniform float uSize;

varying float vCondensed;
varying float vAlpha;

${L.HASH}
${L.NOISE}

void main() {
  float phase = position.x;
  float lane  = position.y;
  float vary  = position.z;

  // Drift: right (interior) toward left (exterior). Slow — this is diffusion.
  float travel = fract(phase + uTime * 0.021);
  float x = 1.0 - travel;

  // The random walk that dominates the motion.
  float wx = fbm(vec2(phase * 53.0, uTime * 0.055 + vary * 17.0)) - 0.5;
  float wy = fbm(vec2(phase * 31.0 + 9.0, uTime * 0.05 + lane * 29.0)) - 0.5;

  x += wx * 0.06;
  float y = lane + wy * 0.16;

  // Crossing dew point, the carrier can no longer stay vapour. It slows and
  // gathers at the plane — but only near it. Past the plane the assembly is
  // drying outward, so carriers there keep moving rather than being held.
  float past = smoothstep(uDew + 0.02, uDew - 0.02, x);
  // Squared by multiplication: pow() with a negative base is undefined in
  // GLSL, and this distance is signed.
  float offset = (x - uDew) / 0.055;
  float atPlane = exp(-offset * offset);
  float settleJitter = (hash11(phase * 411.0) - 0.5) * 0.03;

  x = mix(x, uDew + settleJitter, atPlane * 0.72);
  y = mix(y, lane + wy * 0.05, atPlane * 0.55);

  // Liquid where it has gathered, and still liquid on the way out.
  vCondensed = clamp(max(atPlane, past * 0.55), 0.0, 1.0);

  // More moisture in the air means more carriers are visible at all.
  float presence = 0.45 + uHumidity * 0.55;
  vAlpha = presence
         * mix(0.62, 1.0, atPlane)
         * (0.6 + 0.4 * sin(travel * 3.14159265));

  gl_PointSize = uSize * uPixelRatio * mix(1.0, 1.7, atPlane);
  gl_Position = vec4(vec2(x, 1.0 - y) * 2.0 - 1.0, 0.0, 1.0);
}
`,z=`
precision mediump float;

uniform float uOpacity;

varying float vCondensed;
varying float vAlpha;

${L.POINT_MASK}

void main() {
  float mask = pointMask(gl_PointCoord, 0.42);
  if (mask <= 0.002) discard;

  // Restrained: vapour is a cool grey, condensate a muted blue — not neon.
  vec3 vapour = vec3(0.50, 0.55, 0.61);
  vec3 liquid = vec3(0.40, 0.58, 0.76);
  vec3 colour = mix(vapour, liquid, vCondensed);

  gl_FragColor = vec4(colour * mask * vAlpha * uOpacity, 1.0);
}
`,B=`
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = vec4(position.xy * 2.0, 0.0, 1.0);
}
`,C=`
precision mediump float;

uniform float uDew;
uniform float uAspect;

varying vec2 vUv;

${L.HASH}

void main() {
  vec2 p = vec2(vUv.x * uAspect, vUv.y);

  // A field of pores on a jittered lattice.
  float cell = 0.028;
  vec2 id = floor(p / cell);
  vec2 local = fract(p / cell) - 0.5;
  vec2 jitter = vec2(hash11(dot(id, vec2(1.0, 57.0))),
                     hash11(dot(id, vec2(37.0, 11.0)))) - 0.5;
  float r = 0.16 + hash11(dot(id, vec2(19.0, 7.0))) * 0.16;
  float d = length(local - jitter * 0.5);
  float pore = 1.0 - smoothstep(r, r + 0.1, d);

  float base = 0.085 + pore * 0.11;

  // The cold side of the dew-point plane sits fractionally darker.
  float cold = smoothstep(uDew + 0.06, uDew - 0.06, vUv.x);
  vec3 colour = mix(vec3(0.55, 0.57, 0.60), vec3(0.34, 0.45, 0.58), cold);

  gl_FragColor = vec4(colour * base, base);
}
`;function W({controls:e,count:l=9e3}){let{animate:i}=(0,u.useVizEnv)(),{gl:s,size:o}=(0,b.useThree)(),d=(0,u.useAreaBudget)(l),c=(0,a.useMemo)(()=>{let e=new Float32Array(3*d);for(let t=0;t<d;t++)e[3*t]=Math.random(),e[3*t+1]=Math.random(),e[3*t+2]=Math.random();let t=new r.BufferGeometry;return t.setAttribute("position",new r.BufferAttribute(e,3)),t},[d]),h=(0,a.useMemo)(()=>({uTime:{value:0},uHumidity:{value:.5},uDew:{value:.42},uPixelRatio:{value:1},uSize:{value:2.4},uOpacity:{value:.9}}),[]),m=(0,a.useMemo)(()=>({uDew:{value:.42},uAspect:{value:1.78}}),[]),f=(0,a.useRef)(null),p=(0,a.useRef)(null),v=(0,a.useRef)(0),x=(0,a.useRef)(.5),g=(0,a.useRef)(.42);return(0,n.useFrame)((t,a)=>{let n=Math.min(a,1/24);i&&(v.current+=n);let r=e.current,l=e=>i?Math.min(1,n*e):1;if(x.current+=(r.humidity-x.current)*l(4),g.current+=(r.dewPoint-g.current)*l(3.5),f.current){let e=f.current.uniforms;e.uTime.value=v.current,e.uHumidity.value=x.current,e.uDew.value=g.current,e.uPixelRatio.value=s.getPixelRatio()}p.current&&(p.current.uniforms.uDew.value=g.current,p.current.uniforms.uAspect.value=o.width/Math.max(o.height,1))}),(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)("mesh",{frustumCulled:!1,renderOrder:-1,children:[(0,t.jsx)("planeGeometry",{args:[1,1]}),(0,t.jsx)("shaderMaterial",{ref:p,vertexShader:B,fragmentShader:C,uniforms:m,transparent:!0,depthWrite:!1,depthTest:!1})]}),(0,t.jsx)("points",{frustumCulled:!1,geometry:c,children:(0,t.jsx)("shaderMaterial",{ref:f,vertexShader:R,fragmentShader:z,uniforms:h,transparent:!0,depthWrite:!1,depthTest:!1,blending:r.AdditiveBlending})})]})}var D=e.i(56572);function V(e,t){return Math.min(Math.max(.62-.42*e+.26*t,.06),.86)}function q({discipline:e}){let[n,r]=(0,a.useState)(.55),[l,i]=(0,a.useState)(.3),s=V(n,l),o=(0,a.useRef)({humidity:.55,dewPoint:s}),d=Math.round(20+70*n),c=s>.18&&s<.62;return(0,t.jsxs)(f,{figure:"Fig. 04 — Vapour through a build-up",hint:"Raise interior humidity and watch the plane move outward",caption:e.altText,controls:(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(p,{id:"moisture-rh",label:"Interior relative humidity",display:`${d} %`,valueText:`${d} per cent relative humidity`,min:0,max:1,step:.01,value:n,onChange:e=>{r(e),o.current.humidity=e,o.current.dewPoint=V(e,l)}}),(0,t.jsx)(p,{id:"moisture-vcl",label:"Vapour control",display:l<.2?"Vapour open":l<.65?"Moderate":"Vapour tight",valueText:`Vapour control ${Math.round(100*l)} per cent`,min:0,max:1,step:.01,value:l,onChange:e=>{i(e),o.current.dewPoint=V(n,e)}})]}),overlay:(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("span",{className:D.default.plane,style:{left:`${100*s}%`},"aria-hidden":"true",children:(0,t.jsx)("span",{className:D.default.planeLabel,children:"Dew point"})}),(0,t.jsxs)("span",{className:`${D.default.side} ${D.default.sideLeft}`,children:[(0,t.jsx)("span",{className:D.default.sideName,children:"Exterior"}),(0,t.jsx)("span",{className:D.default.sideValue,children:"Cool · dry"})]}),(0,t.jsxs)("span",{className:`${D.default.side} ${D.default.sideRight}`,children:[(0,t.jsx)("span",{className:D.default.sideName,children:"Interior"}),(0,t.jsxs)("span",{className:D.default.sideValue,children:[d," % RH"]})]}),(0,t.jsx)("span",{className:D.default.drift,children:"Vapour drive ← outward"}),(0,t.jsx)("span",{className:`${D.default.verdict} ${c?D.default.verdictRisk:D.default.verdictSafe}`,children:c?"Condensation plane inside the structural depth":"Condensation plane clear of the structure"})]}),children:[(0,t.jsxs)(u.VizCanvas,{label:e.altText,children:[(0,t.jsx)(u.Invalidate,{signal:`${n}|${l}`}),(0,t.jsx)(W,{controls:o})]}),(0,t.jsxs)("span",{className:"sr-only",children:["With interior humidity at ",d," per cent and"," ",l<.2?"a vapour-open":l<.65?"a moderately vapour-resistant":"a vapour-tight"," ","inner layer, the condensation plane sits"," ",Math.round(100*s)," per cent of the way through the build-up from the exterior face —"," ",c?"inside the structural depth, where accumulated moisture would be a durability risk.":"clear of the structural depth."]})]})}let k=Math.PI/180,O=[17,47,75,105,135,162,198,228,258,288,318,344],G=["January","February","March","April","May","June","July","August","September","October","November","December"];function H(e){return 23.45*Math.sin(360*(284+e)/365*k)}function U(e){return O[Math.min(Math.max(e,0),11)]}function Z(e,t,a){let n=e*k,r=H(U(t))*k,l=(a-12)*15*k,i=Math.asin(Math.min(Math.max(Math.sin(n)*Math.sin(r)+Math.cos(n)*Math.cos(r)*Math.cos(l),-1),1)),s=Math.atan2(Math.sin(l),Math.cos(l)*Math.sin(n)-Math.tan(r)*Math.cos(n)),o=Math.cos(i);return{altitude:i/k,azimuth:s/k,direction:[o*Math.sin(s),Math.sin(i),o*Math.cos(s)],up:i>0}}function J(e,t,a=96){let n=[];for(let r=0;r<=a;r++)n.push(Z(e,t,r/a*24));return n}function X(e){let t=Math.floor(e),a=Math.round((e-t)*60);return`${String(t).padStart(2,"0")}:${String(a).padStart(2,"0")}`}function Y(){let e=(0,a.useMemo)(()=>new r.MeshStandardMaterial({color:"#8d9299",roughness:.92,metalness:0}),[]),n=(0,a.useMemo)(()=>new r.MeshStandardMaterial({color:"#757a81",roughness:.95,metalness:0}),[]);return(0,a.useEffect)(()=>()=>{e.dispose(),n.dispose()},[e,n]),(0,t.jsxs)("group",{children:[(0,t.jsx)("mesh",{position:[-.6,1.75,0],castShadow:!0,receiveShadow:!0,material:e,children:(0,t.jsx)("boxGeometry",{args:[3.4,3.5,2.8]})}),(0,t.jsx)("mesh",{position:[2.1,.85,.5],castShadow:!0,receiveShadow:!0,material:n,children:(0,t.jsx)("boxGeometry",{args:[2,1.7,2.2]})}),Array.from({length:6},(e,a)=>(0,t.jsx)("mesh",{position:[-2.45,.75+.58*a,0],castShadow:!0,receiveShadow:!0,material:n,children:(0,t.jsx)("boxGeometry",{args:[.8,.06,2.8]})},a))]})}function K({points:e,color:n,opacity:l}){let i=(0,a.useMemo)(()=>{let t=new r.BufferGeometry().setFromPoints(e),a=new r.LineBasicMaterial({color:new r.Color(n),transparent:!0,opacity:l}),i=new r.Line(t,a);return i.frustumCulled=!1,i},[e,n,l]);return((0,a.useEffect)(()=>()=>{i.geometry.dispose(),i.material.dispose()},[i]),e.length<2)?null:(0,t.jsx)("primitive",{object:i})}function Q({latitude:e,month:l,hour:i}){let{tier:s,animate:o}=(0,u.useVizEnv)(),{camera:d}=(0,b.useThree)(),c=(0,a.useRef)(null),h=(0,a.useRef)(null),m=(0,a.useRef)(null),f=(0,a.useRef)({latitude:e,month:l,hour:i});f.current={latitude:e,month:l,hour:i};let p=(0,a.useRef)({latitude:e,month:l,hour:i}),v=(0,a.useMemo)(()=>J(e,l).filter(e=>e.altitude>-1.5).map(e=>new r.Vector3(15*e.direction[0],15*e.direction[1],15*e.direction[2])),[e,l]),x=(0,a.useMemo)(()=>{let t=t=>J(e,t).filter(e=>e.altitude>-1.5).map(e=>new r.Vector3(15*e.direction[0],15*e.direction[1],15*e.direction[2]));return{june:t(5),december:t(11)}},[e]),g=(0,a.useMemo)(()=>{let e=[];for(let t=0;t<=96;t++){let a=t/96*Math.PI*2;e.push(new r.Vector3(9*Math.sin(a),.01,9*Math.cos(a)))}return e},[]);(0,a.useEffect)(()=>{d.position.set(15.5,10.5,19),d.lookAt(0,1.2,0)},[d]),(0,n.useFrame)((e,t)=>{let a=Math.min(t,.05),n=o?Math.min(1,7*a):1,r=p.current,l=f.current;r.latitude+=(l.latitude-r.latitude)*n,r.month+=(l.month-r.month)*n,r.hour+=(l.hour-r.hour)*n;let i=Z(r.latitude,Math.round(r.month),r.hour),[s,u,d]=i.direction,v=c.current;if(v){v.position.set(15*s,15*Math.max(u,.02),15*d);let e=Math.max(i.altitude,0)/90;v.intensity=i.up?.2+1.9*Math.pow(e,.6):0,v.color.setHSL(.085,.42*(1-e),.52+.48*e)}let x=h.current;x&&(x.position.set(15*s,15*u,15*d),x.visible=i.up),m.current&&(m.current.intensity=i.up?.85:.25)});let _="high"===s?2048:1024;return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("color",{attach:"background",args:["#0a0c0e"]}),(0,t.jsx)("fog",{attach:"fog",args:["#0a0c0e",30,62]}),(0,t.jsx)("hemisphereLight",{ref:m,args:["#6d86a0","#0e1114",.55]}),(0,t.jsx)("directionalLight",{ref:c,castShadow:!0,intensity:2.2,"shadow-mapSize-width":_,"shadow-mapSize-height":_,"shadow-bias":-.0012,"shadow-normalBias":.02,"shadow-camera-near":1,"shadow-camera-far":64,"shadow-camera-left":-11,"shadow-camera-right":11,"shadow-camera-top":11,"shadow-camera-bottom":-11}),(0,t.jsxs)("mesh",{ref:h,children:[(0,t.jsx)("sphereGeometry",{args:[.42,20,20]}),(0,t.jsx)("meshBasicMaterial",{color:"#f2e9dc"})]}),(0,t.jsxs)("mesh",{rotation:[-Math.PI/2,0,0],receiveShadow:!0,children:[(0,t.jsx)("planeGeometry",{args:[54,54]}),(0,t.jsx)("meshStandardMaterial",{color:"#272b30",roughness:1,metalness:0})]}),(0,t.jsx)(K,{points:g,color:"#ece9e3",opacity:.13}),(0,t.jsx)(K,{points:x.june,color:"#ece9e3",opacity:.22}),(0,t.jsx)(K,{points:x.december,color:"#ece9e3",opacity:.22}),(0,t.jsx)(K,{points:v,color:"#4c7db8",opacity:.62}),(0,t.jsx)(Y,{})]})}var ee=e.i(71784);function et({discipline:e}){let n=(0,a.useRef)(null),[r,l]=(0,a.useState)(28.6),[i,s]=(0,a.useState)(5),[o,d]=(0,a.useState)(10);(0,a.useEffect)(()=>{let e=n.current;if(!e)return;let t=!1,a=0,r=0,l=n=>{t=!0,a=n.clientX,r=n.clientY,e.setPointerCapture(n.pointerId)},i=n=>{if(!t)return;let l=e.getBoundingClientRect(),i=(n.clientX-a)/l.width,o=(n.clientY-r)/l.height;a=n.clientX,r=n.clientY,d(e=>Math.min(Math.max(e+26*i,0),24)),s(e=>Math.min(Math.max(e+14*o,0),11))},o=a=>{t=!1,e.hasPointerCapture(a.pointerId)&&e.releasePointerCapture(a.pointerId)};return e.addEventListener("pointerdown",l),e.addEventListener("pointermove",i),e.addEventListener("pointerup",o),e.addEventListener("pointercancel",o),()=>{e.removeEventListener("pointerdown",l),e.removeEventListener("pointermove",i),e.removeEventListener("pointerup",o),e.removeEventListener("pointercancel",o)}},[]);let c=Math.round(i),h=Z(r,c,o),m=function(e,t){let a=H(U(t))*k,n=-Math.tan(e*k)*Math.tan(a);if(n<-1||n>1)return null;let r=Math.acos(n)/k/15;return{sunrise:12-r,sunset:12+r,length:2*r}}(r,c);return(0,t.jsxs)(f,{figure:"Fig. 02 — Sun path and shadow",hint:"Drag: sideways for time of day, up and down for month",caption:e.altText,draggable:!0,stageRef:n,controls:(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(p,{id:"solar-latitude",label:"Latitude",display:`${r.toFixed(1)}\xb0 N`,valueText:`${r.toFixed(1)} degrees north`,min:8,max:35,step:.1,value:r,onChange:l}),(0,t.jsx)(p,{id:"solar-month",label:"Month",display:G[c],valueText:G[c],min:0,max:11,step:1,value:c,onChange:s}),(0,t.jsx)(p,{id:"solar-hour",label:"Solar time",display:X(o),valueText:`${X(o)} solar time`,min:0,max:24,step:.25,value:o,onChange:d})]}),overlay:(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)("div",{className:ee.default.readout,children:[(0,t.jsxs)("span",{className:ee.default.row,children:[(0,t.jsx)("span",{className:ee.default.term,children:"Altitude"}),(0,t.jsxs)("span",{className:ee.default.value,children:[h.altitude.toFixed(1),"°"]})]}),(0,t.jsxs)("span",{className:ee.default.row,children:[(0,t.jsx)("span",{className:ee.default.term,children:"Azimuth"}),(0,t.jsxs)("span",{className:ee.default.value,children:[h.azimuth.toFixed(1),"°"]})]}),(0,t.jsxs)("span",{className:ee.default.row,children:[(0,t.jsx)("span",{className:ee.default.term,children:"Day length"}),(0,t.jsx)("span",{className:ee.default.value,children:m?`${m.length.toFixed(1)} h`:"—"})]})]}),(0,t.jsx)("span",{className:`${ee.default.state} ${h.up?ee.default.stateUp:""}`,children:h.up?"Sun above horizon":"Sun below horizon"}),(0,t.jsx)("span",{className:ee.default.compass,children:"Azimuth measured from south, positive west"})]}),children:[(0,t.jsx)(u.VizCanvas,{label:e.altText,shadows:!0,flat:!0,interactive:!0,camera:{position:[15.5,10.5,19],fov:30,near:.5,far:140},children:(0,t.jsx)(Q,{latitude:r,month:c,hour:o})}),(0,t.jsxs)("span",{className:"sr-only",children:["At latitude ",r.toFixed(1)," degrees north in"," ",G[c]," at ",X(o)," solar time, the sun sits at an altitude of ",h.altitude.toFixed(1)," degrees and an azimuth of"," ",h.azimuth.toFixed(1)," degrees from south."," ",h.up?"The building casts a shadow across the ground.":"The sun is below the horizon and the model is unlit."]})]})}var ea=e.i(65889),en=e.i(30361),er=e.i(96951);function el({discipline:e}){let n=(0,a.useRef)(null),[r,l]=(0,a.useState)(38),i=(0,a.useRef)({reveal:1,progress:0,exterior:.6428571428571429}),s=(0,er.usePointerField)(n),o=24+(r-24)*.055,d=r-o;return(0,t.jsxs)(f,{figure:"Fig. 01 — Envelope section",hint:"Move across the section to add a heat source",caption:e.altText,stageRef:n,controls:(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(p,{id:"thermal-exterior",label:"Exterior condition",display:`${r.toFixed(0)} \xb0C`,valueText:`${r.toFixed(0)} degrees Celsius`,min:20,max:48,step:.5,value:r,onChange:e=>{l(e),i.current.exterior=(e-20)/28}}),(0,t.jsx)(p,{id:"thermal-interior",label:"Interior (design condition)",display:`${o.toFixed(1)} \xb0C`,valueText:`${o.toFixed(1)} degrees Celsius`,min:24,max:24,step:1,value:24,onChange:()=>{}})]}),overlay:(0,t.jsx)(ea.EnvelopeSection,{active:!0,exteriorTemp:r,interiorTemp:o}),children:[(0,t.jsxs)(u.VizCanvas,{label:e.altText,children:[(0,t.jsx)(u.Invalidate,{signal:r}),(0,t.jsx)(en.ThermalField,{pointer:s,controls:i,count:18e3})]}),(0,t.jsxs)("span",{className:"sr-only",children:["Temperature difference across the assembly: ",d.toFixed(1)," kelvin."]})]})}e.s(["DisciplineInstrument",0,function({discipline:e}){switch(e.slug){case"thermal":return(0,t.jsx)(el,{discipline:e});case"solar":return(0,t.jsx)(et,{discipline:e});case"air":return(0,t.jsx)(y,{discipline:e});case"moisture":return(0,t.jsx)(q,{discipline:e});case"daylight":return(0,t.jsx)(I,{discipline:e});case"energy":return(0,t.jsx)(P,{discipline:e})}}],33950)},64135,e=>{e.v({caption:"Instrument-module__xlZd6a__caption",control:"Instrument-module__xlZd6a__control",controlHead:"Instrument-module__xlZd6a__controlHead",controlValue:"Instrument-module__xlZd6a__controlValue",controls:"Instrument-module__xlZd6a__controls",head:"Instrument-module__xlZd6a__head",hint:"Instrument-module__xlZd6a__hint",instrument:"Instrument-module__xlZd6a__instrument",overlay:"Instrument-module__xlZd6a__overlay",slider:"Instrument-module__xlZd6a__slider",stage:"Instrument-module__xlZd6a__stage",toggle:"Instrument-module__xlZd6a__toggle",toggles:"Instrument-module__xlZd6a__toggles"})},941,e=>{e.v({dialArrow:"AirInstrument-module__WMzg6q__dialArrow",dialLabel:"AirInstrument-module__WMzg6q__dialLabel",dialRing:"AirInstrument-module__WMzg6q__dialRing",ground:"AirInstrument-module__WMzg6q__ground",opening:"AirInstrument-module__WMzg6q__opening",overlaySvg:"AirInstrument-module__WMzg6q__overlaySvg",readout:"AirInstrument-module__WMzg6q__readout",solid:"AirInstrument-module__WMzg6q__solid",term:"AirInstrument-module__WMzg6q__term",value:"AirInstrument-module__WMzg6q__value",windDial:"AirInstrument-module__WMzg6q__windDial",zoneNote:"AirInstrument-module__WMzg6q__zoneNote",zones:"AirInstrument-module__WMzg6q__zones"})}]);